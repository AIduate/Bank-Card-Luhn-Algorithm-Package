from setuptools import setup

setup(name='iduate_bank_card',
      version='2.0',
      description='BankCard - Luhn Algorithm',
      packages=['bank_card'],
      zip_safe=False)
