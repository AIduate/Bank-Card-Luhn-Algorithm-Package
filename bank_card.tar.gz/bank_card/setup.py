from setuptools import setup

setup(name='iduate_bank_card',
      version='1.0',
      description='Bank Card - Luhn Algorithm',
      packages=['iduate_bank_card'],
      zip_safe=False)
